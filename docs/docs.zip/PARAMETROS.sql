CREATE TABLE parametros (
    NomeRelatorio VARCHAR(100) NOT NULL, -- Nome do relatório
    Caminho VARCHAR(255) NOT NULL       -- Caminho do relatório
);